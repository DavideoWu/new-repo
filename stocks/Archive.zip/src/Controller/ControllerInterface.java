package Controller;

public interface ControllerInterface {
  void go();
}
